"""Utility helpers (logging, formatting)."""

