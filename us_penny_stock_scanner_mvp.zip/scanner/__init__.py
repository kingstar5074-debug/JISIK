"""Core scanning package."""

